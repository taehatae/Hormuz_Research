# 고정200개 본문 시험 — 준비 완료, 실제 수집 미실행

## 2026-11-08 오프라인 회귀 보완

최신 안내는 [회귀 보고서](OFFLINE_REGRESSION_REPORT.md), [실행 전 점검표](PRE_EXECUTION_CHECKLIST.md), [기사별 지표와 분모](RESULT_METRIC_DEFINITIONS.md)다. 기존 큐·설정·상태 원장은 유지한다. 실제 실행 승인은 여전히 없다.

전체 회귀 테스트는 프로젝트 루트에서 `python -B scripts/verify_body_pilot_200_regression.py tests`로 실행한다. 기존 아래 32개 테스트 명령은 원래 테스트만 실행한다. 최신 전체 검증은 `offline_regression_validation.json`, `regression_final_tests.log`, `regression_dry_run.json`, `offline_regression_manifest.json`을 본다. 기존 manifest/validation은 최초 준비 시점의 기록이다.

실제 승인 실행 이후에는 `pilot_outcomes.csv`와 `pilot_summary.json`으로 접근/HTML/본문/영어/키워드/품질/사람 검토를 분리해 집계한다. `done` 또는 `review` 수를 유효 본문 수로 해석하지 않는다. 현재 `offline_initial_*`는 전부 미시도인 상태의 확인표다.

큐와 초기 상태를 고정했다. actual HTTP/robots/API/HTML 다운로드/실제 뉴스 추출은 수행하지 않았다. 활용 가능한 영어 본문20,000건 이상이라는 향후 목표의 달성 여부를 이번 준비 결과로 판단하지 않는다.

## 먼저 읽기

[선정 결과](pilot_selection_report.md) → [실행 계획](PILOT_EXECUTION_PLAN.md) → [품질 프로토콜](PILOT_QUALITY_PROTOCOL.md) → [검증](validation.json). 검색 설정 근거는 newscatcher_query_summary.json/evidence.json에 있다.

## 현재 허용되는 오프라인 점검

프로젝트 루트에서:

```powershell
$env:PYTHONDONTWRITEBYTECODE="1"
python -B scripts/body_pilot_200.py --run-dir hormuz_2026_data/runs/body_pilot_200_20261107_01
python -B -m unittest discover -s scripts -p test_body_pilot_200.py -v
```

모의 테스트 32개 통과. mock_test_results.log와 mock_test_warnings.json을 확인한다. 실제 설치된 trafilatura/news-please를 합성 HTML로 호출했지만 실제 기사 성공 사례는 0건이다. 테스트 중 외부 DNS/네트워크는 차단했고 임시 mock 출력은 이 파일의 실제 article 폴더와 분리했다.

## 별도 사용자 승인 후에만

현재 execution_approval_TEMPLATE.json의 approved=false를 유지한다. 향후 승인이 있으면 별도 승인 파일에 큐 SHA/200개/승인자·시각과 도메인별 이용 조건 근거를 기록한다. robots는 실제 실행 시 확인한다. 승인 파일이 없거나 hash가 다르면 실행이 거절된다.

```powershell
python -B scripts/body_pilot_200.py --run-dir hormuz_2026_data/runs/body_pilot_200_20261107_01 --execute --approval-file <나중에_승인된_파일.json>
```

위 실제 실행 명령은 이번에 실행하지 않았다. terms 미확인 도메인과 새 redirect 도메인은 review/차단되므로 200개가 모두 요청/성공한다고 보장하지 않는다. serial one-pass이고 due 전 오류는 보류된다. 재개는 같은 명령에서 terminal 결과를 건너뛰며 입력 큐는 바꾸지 않는다.

## 결과 확인

pilot_state.csv의 pending/running/done/review/error/policy_blocked, events.jsonl, request_activity.json, 결과 JSON의 HTTP/HTML/추출/언어/키워드/품질·중복 항목을 구분해 집계한다. attempt는 논리 시도이며 robots/redirect 실제 응답 활동과 다를 수 있다. html/은 원 HTML, texts/는 추출기별 전체 텍스트, results/는 검토 정보, robots/는 정책 응답이다. 자동 통과를 최종 정답/20,000건 목표 달성으로 세지 않는다.

manifest.json은 준비 시점 파일 해시다. 실제 실행 후 state/결과/로그가 변하는 것은 명시된 mutable 산출물 변경이며 준비 manifest를 고쳐 과거를 덮어쓰지 않는다. pilot_lock.json은 큐/config/runner를 고정한다. 해당 코드/설정이 바뀌면 조용히 hash를 갱신하지 말고 새 검토·준비 버전을 만든다.

기존 125,948개 큐, 원본 두 CSV, 기존 노트북·보고서·51건 시험은 읽기 전용으로 유지했다. Git commit/push와 패키지 다운로드를 하지 않았다.
