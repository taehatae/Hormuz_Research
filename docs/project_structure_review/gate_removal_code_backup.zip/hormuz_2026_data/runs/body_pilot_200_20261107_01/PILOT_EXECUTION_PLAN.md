# 200개 시험 실제 실행 계획 — 현재는 실행 승인 없음

## 2026-11-08 보완 사항

최신 기준은 [실행 전 점검표](PRE_EXECUTION_CHECKLIST.md), [오프라인 회귀 보고서](OFFLINE_REGRESSION_REPORT.md), [지표 정의](RESULT_METRIC_DEFINITIONS.md)다. 현재 실행 승인은 없고 기존 200개 및 상태·설정은 유지한다.

robots는 UTF-8·문법·규칙을 보수적으로 확인하며 지원하지 않거나 모호한 내용은 review다. 가장 구체적인 agent/경로, Allow 동률 우선, wildcard와 Crawl-delay/Request-rate를 처리한다. 빈 파일·404/410은 robots 지시 부재일 뿐 이용 조건 허가가 아니다. 새 도메인 정책은 DNS 전에 확인한다.

429/5xx Retry-After는 서버가 지정한 전체 대기 시간을 보존한다. 자동 대기 범위 초과는 manual review로 보낸다. 과거 설정 `max_retry_after_sec=3600`은 서버 대기 시간을 자르는 상한이 아니라 자동 처리 범위다. 설정은 바꾸지 않았다.

논리 attempts와 transport 시작/응답/오류를 별도 누적 기록한다. 미완료 시작 기록은 결과 불명이며 무조건 재요청하지 않는다. 선언 길이보다 짧은 응답은 검토하고 추출하지 않는다. HTML 재사용 시 원래 URL·ID·해시를 확인한다. 검토 결과는 자동 삭제·교체하지 않는다.

승인 실행 종료 시 `pilot_outcomes.csv`·`pilot_summary.json`을 생성한다. 기본 dry-run은 상태/기사 파일을 쓰지 않고 요약을 출력한다. 현재 잠금은 회귀 검증 뒤 코드 해시만 갱신하고 큐·설정 해시는 유지한다. 최초 준비 manifest를 소급 수정하지 않는다.

향후 활용 가능한 영어 본문 20,000건 이상은 사용자 전달 최소 목표다. 이번에는 고정200 URL의 기술적 가능성을 시험할 준비만 했다. 200개의 성공률을 전체 원자료의 확보율로 일반화하거나 고정 연구 가설을 만들지 않는다.

## 실행 전

1. 별도 사용자 실행 승인을 받는다. 준비 승인을 실제 요청 승인으로 재해석하지 않는다. 큐/config/runner hash를 pilot_lock.json과 비교한다.
2. execution_approval_TEMPLATE.json은 approved=false인 비승인 양식이다. 이후 명시 승인에 근거해 별도 approval 파일을 만들고 approved_by/approved_at(시간대 포함)/큐 SHA/정확히200개를 기록한다. 양식 자체는 승인으로 쓰지 않는다.
3. 각 도메인 이용 조건/접근 정책을 검토해 domain_policies의 terms_reviewed, allowed, evidence를 기록한다. robots 허용은 이용 조건 검토·법적 사용 허가와 다르다. 미확인은 요청 전에 review이며 robots 요청도 하지 않는다. 리디렉션으로 다른 도메인이 등장하면 그 도메인도 별도 근거가 필요하다.
4. 기본 실행은 dry-run이며 DNS·기사·robots 요청이 없다. 실제 실행에는 --execute와 --approval-file이 모두 필요하다. 현재 실행하지 않았다.

## 실제 요청 시 동작

- 동시성1, 기본 도메인 최소2초, robots Crawl-delay/Request-rate가 더 보수적이면 그 값을 적용한다. robots 요청도 같은 rate limiter를 사용한다. 원본 URL의 scheme/host/port/credential/query를 검사하고 DNS의 모든 IP가 public인지 확인한다. localhost·사설/링크로컬·내부/예약 호스트·혼합 DNS·자격증명 URL은 차단한다.
- 검증 IP에 연결을 고정해 DNS 재해석을 피하고 HTTPS 원래 호스트의 SNI/인증서 검증을 유지한다. 프록시 환경·인증·쿠키 jar를 사용하지 않는다. 명확한 User-Agent를 사용한다. HTTP로 주어진 URL을 임의로 HTTPS로 바꾸지 않으며 HTTPS→HTTP 리디렉션은 차단한다.
- 각 리디렉션도 최대5회까지 안전성·도메인 이용 조건·robots를 확인한다. 기사 내부 링크·canonical·추천 URL을 새 기사로 추가하지 않는다. 기사 입력 allowlist는 잠긴200개뿐이다. robots와 같은 기사의 제한된 redirect는 접근 단계이며 200개 외 새 기사 표본이 아니다.
- robots 404/410은 지시 없음으로 처리하되 이용 조건은 여전히 필요하다. robots 401/403은 차단, 5xx·429는 제한 재시도/쿨다운, HTML로 대체된 robots·불명 상태는 review다. 리디렉션된 robots는 같은 origin만 허용한다. 매 실행 robots를 다시 확인하고 저장 응답을 근거로 남긴다.
- 연결10초, 읽기30초, 응답 누적60초 deadline. HTML 8MB·robots512KB 제한, Content-Type/HTML signature 확인. Accept-Encoding=identity; 인코딩/압축 예외는 review해 압축폭탄/부분 HTML을 추출하지 않는다.
- 401/403은 우회·자동 재시도 없이 policy_blocked다. 429는 Retry-After와 쿨다운을 적용한다. 5xx/DNS/연결/timeout만 최대2재시도(총3 logical attempts), 지수 백오프. 도메인3회 실패 시 기본900초 circuit breaker. 한 실행은200개의 한 pass뿐이며 due 전 retry를 기다리며 반복하지 않는다.

## 중단·재개

pilot_state.csv는 article_id/시험순번/URL/domain/status/attempts/last_request_at/next_retry_at/http_status/extractor/error_type/html_path/result_path를 저장한다. pending은 미처리, running은 처리 중, done은 프로그램 완료(사람 정답 아님), review는 정책/품질/접근 불확실, error는 기술 실패, policy_blocked는 금지/장벽이다. logical attempts와 실제 HTTP response activity를 구분한다.

done/review/policy_blocked는 자동 재요청하지 않는다. error는 다음 retry 시각·횟수가 허용된 경우만 재시도한다. 중단 당시 running은 현재 attempt와 맞는 terminal 결과+해시가 있으면 복구하고, 검증된 HTML이 있으면 추출만 재개한다. 요청 후 파일이 없거나 이전 attempt 결과만 있으면 review로 보내 중복 refetch를 하지 않는다. orphan HTML/provenance도 review다.

실행 lock이 있으면 두 프로세스를 동시에 실행하지 않는다. 비정상 종료 lock은 PID가 실제 실행 중인지 사람이 확인한 뒤 이 새 run의 lock만 제거한다. 기존 원본 파일을 제거하지 않는다. 프로세스 running 기록 복구 후 새 한 pass를 실행한다. queue/config는 고정하고 상태/로그/결과만 이 run에서 갱신한다.

민감한 headers, API 키, 비밀번호, 인증 토큰, 쿠키를 요청/저장/로그에 사용하지 않는다. 원문 공개 HTML에는 사이트 제공 공개 코드/문구가 있을 수 있으므로 저장 HTML도 비공개 연구 자료로 취급한다. 저장 HTML과 본문은 각각 html/, texts/, 메타데이터/판정은 results/, 정책 근거는 robots/, 상태·오류는 CSV/JSONL로 구분한다.


## Limited parallel HTTP update (2026-11-08)

This section supersedes the original serial scheduling description. Runtime default: 4 workers (`--workers N`); the frozen configuration is unchanged, including its historical concurrency value. Per-host concurrency is 1 across robots, article and redirect requests. State, durable request journals, HTML, extraction and result commits run on the manager thread. Ctrl-C stops new scheduling and drains submitted work. Abrupt termination uses the existing conservative saved-HTML recovery; uncertain request outcomes remain review without refetch. See [report](parallelization_20261108_01/PARALLELIZATION_REPORT.md). Approval requirements are unchanged. No live execution was performed.
